//
//  CredentialViewController.swift
//  BluelyHub
//
//  Created by Bozo Krkeljas on 2/2/21.
//

import UIKit
import WebKit
import SDWebImage

class CredentialViewController: UIViewController, WKNavigationDelegate {

    @IBOutlet weak var expireDate: UILabel!

    public var credential: Credential?
    
    @IBOutlet weak var webView: WKWebView!
       
    override func viewDidLoad() {
        super.viewDidLoad()
  
        if let expire = credential?.expire_date {
            expireDate.text = "Expire Date: \(expire)"
        }
        
        let file_link = APIManager.imagePath + (credential?.file_name)!
        
        webView.load(URLRequest(url: URL(string: file_link)!))
    }
}
