//
//  PersonalViewController.swift
//  BluelyHub
//
//  Created by Bozo Krkeljas on 1/30/21.
//

import UIKit
import SwiftyJSON
import SwiftPhoneNumberFormatter

class PersonalViewController: UIViewController, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    private var isSocial: Bool = false
    public var signupParams: JSON?

    @IBOutlet weak var tfFirstName: UITextField!
    @IBOutlet weak var tfLastName: UITextField!
    @IBOutlet weak var tfBirthday: UITextField!
    @IBOutlet weak var tfPhoneNumber: PhoneFormattedTextField!
    @IBOutlet weak var tfZIPCode: UITextField!
    @IBOutlet weak var tfLicense: UITextField!
    @IBOutlet weak var tfExperience: UITextField!
    @IBOutlet weak var labelPassword: UILabel!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var labelConfirm: UILabel!
    @IBOutlet weak var tfConfirm: UITextField!
    
    @objc func birthdayTapDone() {
        if let datePicker = self.tfBirthday.inputView as? UIDatePicker {
            let dateformatter = DateFormatter()
            dateformatter.dateFormat = "dd-MM-yyyy"
            self.tfBirthday.text = dateformatter.string(from: datePicker.date)
        }
        self.tfBirthday.resignFirstResponder()
    }
    
    @objc func licenseTapDone() {
        if let picker = self.tfLicense.inputView as? UIPickerView {
            let selected = picker.selectedRow(inComponent: 0)
            if let licenses = DataManager.licenses {
                self.tfLicense.text = licenses[selected].name
            }
        }
        
        self.tfLicense.resignFirstResponder()
    }
    
    @objc func expereinceTapDone() {
        if let picker = self.tfExperience.inputView as? UIPickerView {
            let selected = picker.selectedRow(inComponent: 0)
            if selected == 0 {
                self.tfExperience.text = "\(selected + 1) Year"
            } else {
                self.tfExperience.text = "\(selected + 1) Years"
            }
        }
        
        self.tfExperience.resignFirstResponder()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.setHidesBackButton(true, animated: false)
        
        tfBirthday.setDatePicker(target: self, selector: #selector(birthdayTapDone))
        tfLicense.setLicensePicker(target: self, selector: #selector(licenseTapDone))
        if let picker = tfLicense.inputView as? UIPickerView {
            picker.tag = 1
            picker.delegate = self
            picker.dataSource = self
        }
        
        tfExperience.setExperiencePicker(target: self, selector: #selector(expereinceTapDone))
        if let picker = tfExperience.inputView as? UIPickerView {
            picker.tag = 2
            picker.delegate = self
            picker.dataSource = self
        }

        tfPhoneNumber.config.defaultConfiguration = PhoneFormat(defaultPhoneFormat: "(###) ###-##-##")
        tfPhoneNumber.prefix = "+1 "
        
        if let params = signupParams {
            if let firstName = params["firstname"].string {
                tfFirstName.text = firstName
            }
            
            if let lastName = params["lastname"].string {
                tfLastName.text = lastName
            }
            
            // No need to show Password items for Social users
            if params["apple_id"].string != nil ||
                params["google_id"].string != nil ||
                params["fb_id"].string != nil {
                isSocial = true
            }
            
            labelPassword.isHidden = isSocial
            tfPassword.isHidden = isSocial
            labelConfirm.isHidden = isSocial
            tfConfirm.isHidden = isSocial
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func onSave(_ sender: Any) {
        guard let firstName = tfFirstName.text, !firstName.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please first name.")
            return
        }
        
        guard let lastName = tfLastName.text, !lastName.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please last name.")
            return
        }
        
        guard let birthday = tfBirthday.text, !birthday.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input birthday.")
            return
        }
        
        if (!DataManager.isOlderThan(birthday, age: 18)) {
            UIManager.shared.showAlert(vc: self, title: "", message: "You must be at least 18 years of age to sign up.")
            return
        }
        
        guard let phoneNumber = tfPhoneNumber.text, !phoneNumber.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input phone number.")
            return
        }
        
        guard let zipCode = tfZIPCode.text, !zipCode.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input ZIP code.")
            return
        }
        
        guard let license = tfLicense.text, !license.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input your care giving license.")
            return
        }
        
        guard let experience = tfExperience.text, !experience.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input your care giving expereince.")
            return
        }
        
        if (!isSocial) {
            guard let password = tfPassword.text, !password.isEmpty else {
                UIManager.shared.showAlert(vc: self, title: "", message: "Please input password.")
                return
            }
            
            guard let confirm = tfConfirm.text, !confirm.isEmpty else {
                UIManager.shared.showAlert(vc: self, title: "", message: "Please input password")
                return
            }
            
            if (password != confirm) {
                UIManager.shared.showAlert(vc: self, title: "", message: "The password doesn't match.")
                return
            }
            
            if password.count < 6 {
                UIManager.shared.showAlert(vc: self, title: "", message: "Password must be at least 6 characters.")
                return
            }
        }
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        let date = formatter.date(from: birthday)
        formatter.dateFormat = "yyyy-MM-dd"
        let birthdayString = formatter.string(from: date!)
        
        var params: JSON = JSON()
        if let signupParams = self.signupParams {
            params["email"].string = signupParams["email"].string
        }
        
        params["firstname"].string = firstName
        params["lastname"].string = lastName
        params["birthday"].string = birthdayString
        params["phone_number"].string = phoneNumber
        params["zip_code"].string = zipCode
        
        if let picker = self.tfLicense.inputView as? UIPickerView {
            let selected = picker.selectedRow(inComponent: 0)
            params["care_giving_license"].int = DataManager.licenses![selected].id
        }

        if let picker = self.tfExperience.inputView as? UIPickerView {
            let selected = picker.selectedRow(inComponent: 0)
            params["care_giving_experience"].int = selected + 1
        }
        
        if !isSocial {
            params["password"].string = tfPassword.text
        }

        UIManager.shared.showHUD(view: self.view)

        if (isSocial) {
            params["userid"].int = DataManager.currentUser?.id
            
            APIManager.shared.updateProfile(params) { (success, user, msg) in
                
                UIManager.shared.hideHUD()
                
                if success {
                    DataManager.currentUser = user
                    
                    self.performSegue(withIdentifier: "skill", sender: nil)
                } else {
                    UIManager.shared.showAlert(vc: self, title: "", message: msg!)
                }
            }
        } else {
            APIManager.shared.register(params) { (success, user, msg) in
                
                UIManager.shared.hideHUD()
                
                if success {
                    UserDefaults.standard.setValue(DataManager.LoginType.Mail.rawValue, forKey: "login_type")
                    UserDefaults.standard.setValue(user?.email, forKey: "email")
                    UserDefaults.standard.setValue(self.tfPassword.text, forKey: "password")
                    DataManager.currentUser = user
                    
                    self.performSegue(withIdentifier: "skill", sender: nil)
                } else {
                    UIManager.shared.showAlert(vc: self, title: "", message: msg!)
                }
            }
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentCharacterCount = textField.text?.count ?? 0
        if range.length + range.location > currentCharacterCount {
            return false
        }
        
        let newLength = currentCharacterCount + string.count - range.length
        return newLength <= 5
    }
    
    // MARK: - UIPickerViewDataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (pickerView.tag == 1) {
            if let licenses = DataManager.licenses {
                return licenses.count
            }
            
            return 0
        } else if (pickerView.tag == 2) {
            return 50
        }
        
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView.tag == 1 {
            if let licenses = DataManager.licenses {
                return licenses[row].name
            }
        } else {
            if row == 0 {
                return "\(row + 1) Year"
            } else {
                return "\(row + 1) Years"
            }
        }
        
        return ""
    }
}

extension UITextField {
    func setDatePicker(target: Any, selector: Selector) {
        // Create a UIDatePicker object and assign to inputView
        let screenWidth = UIScreen.main.bounds.width
        let datePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
        datePicker.datePickerMode = .date

        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "dd-MM-yyyy"
        if let date = dateformatter.date(from: self.text!) {
            datePicker.date = date
        }

        if #available(iOS 14, *) {// Added condition for iOS 14
            datePicker.preferredDatePickerStyle = .wheels
            datePicker.sizeToFit()
        }
        self.inputView = datePicker
        
        // Create a toolbar and assign it to inputAccessoryView
        let toolBar = UIToolbar(frame: CGRect(x: 0.0, y: 0.0, width: screenWidth, height: 44.0))
        let flexible = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancel = UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: #selector(tapCancel))
        let barButton = UIBarButtonItem(title: "Done", style: .plain, target: target, action: selector)
        toolBar.setItems([cancel, flexible, barButton], animated: false)
        self.inputAccessoryView = toolBar
    }
    
    func setLicensePicker(target: Any, selector: Selector) {
        // Create a UIDatePicker object and assign to inputView
        let screenWidth = UIScreen.main.bounds.width
        let picker = UIPickerView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
        if #available(iOS 14, *) {// Added condition for iOS 14
            picker.sizeToFit()
        }
        self.inputView = picker
        
        // Create a toolbar and assign it to inputAccessoryView
        let toolBar = UIToolbar(frame: CGRect(x: 0.0, y: 0.0, width: screenWidth, height: 44.0))
        let flexible = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancel = UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: #selector(tapCancel))
        let barButton = UIBarButtonItem(title: "Done", style: .plain, target: target, action: selector)
        toolBar.setItems([cancel, flexible, barButton], animated: false)
        self.inputAccessoryView = toolBar
    }
    
    func setExperiencePicker(target: Any, selector: Selector) {
        // Create a UIDatePicker object and assign to inputView
        let screenWidth = UIScreen.main.bounds.width
        let picker = UIPickerView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
        if #available(iOS 14, *) {// Added condition for iOS 14
            picker.sizeToFit()
        }
        self.inputView = picker
        
        // Create a toolbar and assign it to inputAccessoryView
        let toolBar = UIToolbar(frame: CGRect(x: 0.0, y: 0.0, width: screenWidth, height: 44.0))
        let flexible = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancel = UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: #selector(tapCancel))
        let barButton = UIBarButtonItem(title: "Done", style: .plain, target: target, action: selector)
        toolBar.setItems([cancel, flexible, barButton], animated: false)
        self.inputAccessoryView = toolBar
    }
    
    @objc func tapCancel() {
        self.resignFirstResponder()
    }
}
