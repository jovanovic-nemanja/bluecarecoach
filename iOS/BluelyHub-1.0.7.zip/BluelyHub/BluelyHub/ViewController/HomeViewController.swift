//
//  HomeViewController.swift
//  BluelyHub
//
//  Created by Bozo Krkeljas on 2/1/21.
//

import UIKit
import Photos
import SwiftyJSON
import DatePickerDialog
import MessageUI

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var btnAll: UIButton!
    @IBOutlet weak var btnUpload: UIButton!
    @IBOutlet weak var btnNotSet: UIButton!
    
    var credentials: Credentials = Credentials()
    var sel_credentials: Credentials = Credentials()
    var sel_status = "all"
    private var curCredential: Credential?
    var sel_cre_uid = "1"
    
    func initData() {
        self.credentials = []
        self.sel_credentials = []
        if let userID = DataManager.currentUser?.id {
            var params: JSON = JSON()
            params["userid"].int = userID
            params["created_by"].int = 1
            
            UIManager.shared.showHUD(view: self.view)
            
            APIManager.shared.getCredential(params) { (success, credentials, message) in
                UIManager.shared.hideHUD()
                
                if (success) {
                    self.sel_credentials = credentials!
                    if self.sel_status == "all" {
                        self.credentials = self.sel_credentials
                        
                    }else if self.sel_status == "upload" {
                        if self.sel_credentials.count != 0 {
                            for i in 0 ... self.sel_credentials.count - 1 {
                                if self.sel_credentials[i].file_name != nil {
                                    self.credentials.append(self.sel_credentials[i])
                                }
                            }
                        }
                    }else{
                        if self.sel_credentials.count != 0 {
                            for i in 0 ... self.sel_credentials.count - 1 {
                                if self.sel_credentials[i].file_name != nil {
                                }else{
                                    self.credentials.append(self.sel_credentials[i])
                                }
                            }
                        }
                    }
                    
                    self.tableView.reloadData()
                } else {
                    UIManager.shared.showAlert(vc: self, title: "Error", message: message!)
                    return
                }
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        tableView.register(UINib(nibName: "CredentialTableViewCell", bundle: nil), forCellReuseIdentifier: "CredentialCell")
        tableView.tableFooterView = UIView()
        

//        initData()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        initData()
    }
    
    @objc func onAdd() {
        let controller = UIAlertController(title: "Enter credential type", message: nil, preferredStyle: .alert)
        controller.addTextField()

        let submitAction = UIAlertAction(title: "Submit", style: .default) { [unowned controller] _ in
            if let newType = controller.textFields![0].text {
                if newType.count > 0 {
                    var params: JSON = JSON()
                    params["userid"].int = DataManager.currentUser?.id
                    params["title"].string = newType
	
                    UIManager.shared.showHUD(view: self.view, title: "Saving...")

                    APIManager.shared.addCredential(params, { (success, credentials, message) in
                        UIManager.shared.hideHUD()

                        if (success) {
                            if let credentials = credentials {
                                self.credentials = credentials
                                self.tableView.reloadData()
                            }
                        } else {
                            UIManager.shared.showAlert(vc: self, title: "Error", message: message!)
                            return
                        }
                    })
                }
            }
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in

        }

        controller.addAction(submitAction)
        controller.addAction(cancelAction)

        present(controller, animated: true)
    }
    
    func onDelete() {
        let controller = UIAlertController(title: "Delete uploaded credential", message: nil, preferredStyle: .alert)

        let submitAction = UIAlertAction(title: "Yes", style: .default) { [unowned controller] _ in
            var params: JSON = JSON()
            params["userid"].int = DataManager.currentUser?.id
            params["cre_uid"].string = self.sel_cre_uid
            UIManager.shared.showHUD(view: self.view, title: "Processing...")

            APIManager.shared.deleteCredential(params, { (success, credentials, message) in
                UIManager.shared.hideHUD()

                if (success) {
                    if let credentials = credentials {
                        self.credentials = credentials
                        self.tableView.reloadData()
                    }
                } else {
                    UIManager.shared.showAlert(vc: self, title: "Error", message: message!)
                    return
                }
            })
        }

        let cancelAction = UIAlertAction(title: "No", style: .cancel) { (action) in

        }

        controller.addAction(submitAction)
        controller.addAction(cancelAction)

        present(controller, animated: true)
    }

    @objc func onApply() {
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients(["you@yoursite.com"])
            mail.setMessageBody("<p>You're so awesome!</p>", isHTML: true)
            
            present(mail, animated: true)
        } else {
            UIManager.shared.showAlert(vc: self, title: "BluelyHub", message: "Please set up mail account in order to send email")
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        self.tabBarController?.navigationItem.title = "Credentials"

        self.tabBarController?.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(onAdd))
//        self.tabBarController?.navigationItem.leftBarButtonItem?.tintColor = UIColor.systemBlue

        self.tabBarController?.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Email", style: .plain, target: self, action: #selector(onApply))
//        self.tabBarController?.navigationItem.rightBarButtonItem?.tintColor = UIColor.systemBlue
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

//        self.tabBarController?.navigationItem.leftBarButtonItem = nil
//        self.tabBarController?.navigationItem.rightBarButtonItem = nil
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "detail" {
            if let vcDest = segue.destination as? CredentialViewController {
                vcDest.credential = sender as? Credential
            }
        }
    }
    
    
    @IBAction func onAllBtn(_ sender: Any) {
        btnAll.backgroundColor = #colorLiteral(red: 0, green: 0.5019607843, blue: 1, alpha: 1)
        btnAll.setTitleColor(UIColor.white, for: .normal)
        btnUpload.backgroundColor = UIColor.white
        btnUpload.setTitleColor(#colorLiteral(red: 0, green: 0.5019607843, blue: 1, alpha: 1), for: .normal)
        btnNotSet.backgroundColor = UIColor.white
        btnNotSet.setTitleColor(#colorLiteral(red: 0, green: 0.5019607843, blue: 1, alpha: 1), for: .normal)
        
        sel_status = "all"
        initData()
        
    }
    
    @IBAction func onUploadBtn(_ sender: Any) {
        btnAll.backgroundColor = UIColor.white
        btnAll.setTitleColor(#colorLiteral(red: 0, green: 0.5019607843, blue: 1, alpha: 1), for: .normal)
        btnUpload.backgroundColor = #colorLiteral(red: 0, green: 0.5019607843, blue: 1, alpha: 1)
        btnUpload.setTitleColor(UIColor.white, for: .normal)
        btnNotSet.backgroundColor = UIColor.white
        btnNotSet.setTitleColor(#colorLiteral(red: 0, green: 0.5019607843, blue: 1, alpha: 1), for: .normal)
        sel_status = "upload"
        initData()
    }
    
    @IBAction func onNotsetBtn(_ sender: Any) {
        btnAll.backgroundColor = UIColor.white
        btnAll.setTitleColor(#colorLiteral(red: 0, green: 0.5019607843, blue: 1, alpha: 1), for: .normal)
        btnUpload.backgroundColor = UIColor.white
        btnUpload.setTitleColor(#colorLiteral(red: 0, green: 0.5019607843, blue: 1, alpha: 1), for: .normal)
        btnNotSet.backgroundColor = #colorLiteral(red: 0, green: 0.5019607843, blue: 1, alpha: 1)
        btnNotSet.setTitleColor(UIColor.white, for: .normal)
        sel_status = "noset"
        initData()
    }
        
    
    // MARK: -UITableViewDelegate, UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return credentials.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CredentialCell", for: indexPath) as! CredentialTableViewCell

        // Configure the cell...
        cell.setCredential(credentials[indexPath.row])
//        cell.btnEdit.tag = indexPath.row
//
//        cell.btnEdit.addTarget(self, action: #selector(connected(sender:)), for: .touchUpInside)
                
        return cell
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {

        // action one
        let editAction = UITableViewRowAction(style: .default, title: "Edit", handler: { (action, indexPath) in
            let credential = self.credentials[indexPath.row]
            self.showAlertController(credential)
        })
        editAction.backgroundColor = UIColor.blue

        // action two
        let credential = credentials[indexPath.row]
        if (credential.file_name == nil && credential.expire_date == nil) {
            return [editAction]
        }else{
            let deleteAction = UITableViewRowAction(style: .default, title: "Delete", handler: { (action, indexPath) in
                self.sel_cre_uid = credential.cre_uid!
                self.onDelete()
            })
            deleteAction.backgroundColor = UIColor.red
            
            return [editAction, deleteAction]
        }
    }
    
    func isCameraPermissionAuthorized(objViewController: UIViewController, completion:@escaping ((Bool) -> Void)) {

        let status = AVCaptureDevice.authorizationStatus(for: .video)

        switch status {
        case .authorized:
            completion(true)
            break

        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video, completionHandler: { (granted) in
                if granted {
                    completion(true)
                } else {
                    completion(false)
                }
            })
            break

        case .denied, .restricted:
            let strMessage: String = "Please allow access to your photos."
            let alertController = UIAlertController(title: "BluelyHub", message: strMessage, preferredStyle: .alert)

            let cancelAction = UIAlertAction(title: "Ok", style: .default) { action in
                self.dismiss(animated: true, completion: nil)
            }
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true)
            break

        default:
            completion(false)
            break
        }
    }

    func isPhotoPermissionAuthorized(objViewController: UIViewController, completion:@escaping ((Bool) -> Void)) {

        let status = PHPhotoLibrary.authorizationStatus()

        switch status {
        case .authorized:
            completion(true)
            break

        case .notDetermined:
            PHPhotoLibrary.requestAuthorization({ (newStatus) in
                if newStatus == PHAuthorizationStatus.authorized {
                    completion(true)
                } else {
                    completion(false)
                }
            })
            break

        case .denied, .restricted:
            let strMessage: String = "Please allow access to your photos."
            let alertController = UIAlertController(title: "BluelyHub", message: strMessage, preferredStyle: .alert)

            let cancelAction = UIAlertAction(title: "Ok", style: .default) { action in
                self.dismiss(animated: true, completion: nil)
            }
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true)
            break

        default:
            completion(false)
            break
        }
    }
    
    func openImagePicker(sourceType: UIImagePickerController.SourceType) {
        switch sourceType {
        case UIImagePickerController.SourceType.camera:
            isCameraPermissionAuthorized(objViewController: self) { (isAuthorized) in
                if isAuthorized {
                    DispatchQueue.main.async {
                        if (UIImagePickerController.isSourceTypeAvailable(.camera)) {
                            let objImagePicker = UIImagePickerController()
                            UINavigationBar.appearance().tintColor = UIColor.white
                            objImagePicker.allowsEditing = true
                            objImagePicker.delegate = self
                            objImagePicker.sourceType =  sourceType//.photoLibrary
                            objImagePicker.mediaTypes = ["public.image"] //,String(kUTTypeVideo),String(kUTTypeMPEG4)
                            objImagePicker.videoQuality = .typeIFrame960x540//.typeIFrame1280x720 //iFrame960x540
                            self.navigationController?.present(objImagePicker, animated: true, completion: nil)
                        }
                    }
                }
            }
            break
            
        case UIImagePickerController.SourceType.photoLibrary:
            isPhotoPermissionAuthorized(objViewController: self) { (isAuthorized) in
                if isAuthorized {
                    DispatchQueue.main.async {
                        if (UIImagePickerController.isSourceTypeAvailable(.photoLibrary)) {
                            let objImagePicker = UIImagePickerController()
                            UINavigationBar.appearance().tintColor = UIColor.white
                            objImagePicker.allowsEditing = true
                            objImagePicker.delegate = self
                            objImagePicker.sourceType =  sourceType//.photoLibrary
                            objImagePicker.mediaTypes = ["public.image"] //,String(kUTTypeVideo),String(kUTTypeMPEG4)
                            objImagePicker.videoQuality = .typeIFrame960x540//.typeIFrame1280x720 //iFrame960x540
                            self.navigationController?.present(objImagePicker, animated: true, completion: nil)
                        }
                    }
                }
            }
            break

        default:
            break
        }
    }
    
//    @objc func connected(sender: UIButton){
//        _ = sender.tag
//        let credential = credentials[sender.tag]
//
//        showAlertController(credential)
//    }
    
    func showAlertController(_ credential:Credential) {
        self.curCredential = credential
        
        let alertController = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
     
        alertController.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openImagePicker(sourceType: UIImagePickerController.SourceType.camera)
        }))
        
        alertController.addAction(UIAlertAction(title: "Photo Gallery", style: .default, handler: { _ in
            self.openImagePicker(sourceType: UIImagePickerController.SourceType.photoLibrary)
        }))
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alertController, animated: true)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let credential = credentials[indexPath.row]
        
        
        if (credential.file_name == nil && credential.expire_date == nil) {
            showAlertController(credential)
        } else {
            self.performSegue(withIdentifier: "detail", sender: credential)
        }
    }
}

extension HomeViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func uploadCredential(_ date:Date, _ image: UIImage) {
        var params: JSON = JSON()
        params["userid"].int = DataManager.currentUser?.id
        params["credentialid"].string = self.curCredential?.id
        
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd"
        params["expire_date"].string = dateformatter.string(from: date)
        
        UIManager.shared.showHUD(view: self.view, title: "Uploading...")

        APIManager.shared.uploadCredentialFile(params, image, { (success, credentials, msg) in
            UIManager.shared.hideHUD()
            
            if success {
                self.initData()
            } else {
                UIManager.shared.showAlert(vc: self, title: "", message: msg!)
            }
        })
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            // Local variable inserted by Swift 4.2 migrator.
        let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)

        var image: UIImage? = nil
        if let possibleImage = info["UIImagePickerControllerEditedImage"] as? UIImage {
            image = possibleImage
        } else if let possibleImage = info["UIImagePickerControllerOriginalImage"] as? UIImage {
            image = possibleImage
        }

        picker.dismiss(animated: true) {
            if image != nil {
                /*
                DatePickerDialog().show("Choose Expire Date", doneButtonTitle: "Done", cancelButtonTitle: "Cancel", datePickerMode: .date) { date in
                    if let dt = date {
                        self.uploadCredential(dt, image!)
                    }
                }*/
                let myDatePicker: UIDatePicker = UIDatePicker()
                myDatePicker.frame = CGRect(x: 0, y: 15, width: 270, height: 200)
                myDatePicker.datePickerMode = .date
                let alertController = UIAlertController(title: "Choose Expire Date\n\n\n\n\n\n\n\n", message: nil, preferredStyle: .alert)
                alertController.view.addSubview(myDatePicker)
                let selectAction = UIAlertAction(title: "Ok", style: .default, handler: { _ in
                    self.uploadCredential(myDatePicker.date, image!)
                })
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                alertController.addAction(selectAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true)
            }
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    // Helper function inserted by Swift 4.2 migrator.
    fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
        return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
    }
}

extension HomeViewController: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
}

extension UIImage {
    func resize(targetSize: CGSize) -> UIImage {
        return UIGraphicsImageRenderer(size:targetSize).image { _ in
            self.draw(in: CGRect(origin: .zero, size: targetSize))
        }
    }
}
