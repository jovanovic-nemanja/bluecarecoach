//
//  ProfileViewController.swift
//  BluelyHub
//
//  Created by Bozo Krkeljas on 2/1/21.
//

import UIKit
import GoogleSignIn
import FBSDKLoginKit
import SwiftyJSON
import SwiftPhoneNumberFormatter

class ProfileViewController: UIViewController, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    private var isSocial: Bool = false

    @IBOutlet weak var tfFirstName: UITextField!
    @IBOutlet weak var tfLastName: UITextField!
    @IBOutlet weak var tfBirthday: UITextField!
    @IBOutlet weak var tfPhoneNumber: PhoneFormattedTextField!
    @IBOutlet weak var tfZIPCode: UITextField!
    @IBOutlet weak var tfLicense: UITextField!
    @IBOutlet weak var tfExperience: UITextField!
    @IBOutlet weak var btnChangePassword: UIButton!
    
    @objc func birthdayTapDone() {
        if let datePicker = self.tfBirthday.inputView as? UIDatePicker {
            let dateformatter = DateFormatter()
            dateformatter.dateFormat = "dd-MM-yyyy"
            self.tfBirthday.text = dateformatter.string(from: datePicker.date)
        }
        self.tfBirthday.resignFirstResponder()
    }
    
    @objc func licenseTapDone() {      
        if let picker = self.tfLicense.inputView as? UIPickerView {
            let selected = picker.selectedRow(inComponent: 0)
            if let licenses = DataManager.licenses {
                self.tfLicense.text = licenses[selected].name
            }
        }
        
        self.tfLicense.resignFirstResponder()
    }
    
    @objc func expereinceTapDone() {
        if let picker = self.tfExperience.inputView as? UIPickerView {
            let selected = picker.selectedRow(inComponent: 0)
            if selected == 0 {
                self.tfExperience.text = "\(selected + 1) Year"
            } else {
                self.tfExperience.text = "\(selected + 1) Years"
            }
        }
        
        self.tfExperience.resignFirstResponder()
    }
    
    func initData() {
        if let firstName = DataManager.currentUser?.firstname {
            tfFirstName.text = firstName
        }

        if let lastName = DataManager.currentUser?.lastname {
            tfLastName.text = lastName
        }

        if let birthday = DataManager.currentUser?.birthday {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd"
            let date = formatter.date(from: birthday)
            formatter.dateFormat = "dd-MM-yyyy"
            let birthdayString = formatter.string(from: date!)
            tfBirthday.text = birthdayString
        }

        if let phoneNumber = DataManager.currentUser?.phone_number {
            tfPhoneNumber.text = phoneNumber
        }
        
        if let zipCode = DataManager.currentUser?.zip_code {
            tfZIPCode.text = zipCode
        }
        
        if let license = DataManager.currentUser?.care_giving_license {
            if let licenses = DataManager.licenses {
                for item in licenses {
                    if item.id == Int(license) {
                        tfLicense.text = item.name
                    }
                }
            }
        }
        
        if let experience = DataManager.currentUser?.care_giving_experience {
            if let years = Int(experience) {
                if years == 1 {
                    tfExperience.text = "\(years) Year"
                } else {
                    tfExperience.text = "\(years) Years"
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tfBirthday.setDatePicker(target: self, selector: #selector(birthdayTapDone))
        tfLicense.setLicensePicker(target: self, selector: #selector(licenseTapDone))
        if let picker = tfLicense.inputView as? UIPickerView {
            picker.tag = 1
            picker.delegate = self
            picker.dataSource = self
        }
        
        tfExperience.setExperiencePicker(target: self, selector: #selector(expereinceTapDone))
        if let picker = tfExperience.inputView as? UIPickerView {
            picker.tag = 2
            picker.delegate = self
            picker.dataSource = self
        }

        tfPhoneNumber.config.defaultConfiguration = PhoneFormat(defaultPhoneFormat: "(###) ###-##-##")
        tfPhoneNumber.prefix = "+1 "
        
        initData()
    }
    /*
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tabBarController?.navigationItem.title = "Profile"
        
        self.tabBarController?.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(onSave))
//        self.tabBarController?.navigationItem.leftBarButtonItem?.tintColor = UIColor.systemBlue

        self.tabBarController?.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(onLogout))
//        self.tabBarController?.navigationItem.rightBarButtonItem?.tintColor = UIColor.red
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

//        self.tabBarController?.navigationItem.leftBarButtonItem = nil
//        self.tabBarController?.navigationItem.rightBarButtonItem = nil
    }
*/
    @IBAction func onSave(_ sender: Any) {
        guard let firstName = tfFirstName.text, !firstName.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please first name.")
            return
        }
        
        guard let lastName = tfLastName.text, !lastName.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please last name.")
            return
        }
        
        guard let birthday = tfBirthday.text, !birthday.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input birthday.")
            return
        }
        
        if (!DataManager.isOlderThan(birthday, age: 18)) {
            UIManager.shared.showAlert(vc: self, title: "", message: "You must be at least 18 years of age to sign up.")
            return
        }
        
        guard let phoneNumber = tfPhoneNumber.text, !phoneNumber.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input phone number.")
            return
        }
        
        guard let zipCode = tfZIPCode.text, !zipCode.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input ZIP code.")
            return
        }
        
        guard let license = tfLicense.text, !license.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input your care giving license.")
            return
        }
        
        guard let experience = tfExperience.text, !experience.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input your care giving expereince.")
            return
        }
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        let date = formatter.date(from: birthday)
        formatter.dateFormat = "yyyy-MM-dd"
        let birthdayString = formatter.string(from: date!)
        
        var params: JSON = JSON()
        params["userid"].int = DataManager.currentUser?.id
        params["firstname"].string = firstName
        params["lastname"].string = lastName
        params["birthday"].string = birthdayString
        params["phone_number"].string = phoneNumber
        params["zip_code"].string = zipCode
        
        if let picker = self.tfLicense.inputView as? UIPickerView {
            let selected = picker.selectedRow(inComponent: 0)
            params["care_giving_license"].int = DataManager.licenses![selected].id
        }

        if let picker = self.tfExperience.inputView as? UIPickerView {
            let selected = picker.selectedRow(inComponent: 0)
            params["care_giving_experience"].int = selected + 1
        }
        
        UIManager.shared.showHUD(view: self.view)

        APIManager.shared.updateProfile(params) { (success, user, msg) in
            
            UIManager.shared.hideHUD()
            
            if success {
                DataManager.currentUser = user
                self.initData()
            } else {
                UIManager.shared.showAlert(vc: self, title: "", message: msg!)
            }
        }
    }

    @IBAction func onLogout(_ sender: Any) {
        // Google Log Out
        // If this user has logged in with Google
        let loginType = UserDefaults.standard.integer(forKey: "login_type")
        if (loginType == DataManager.LoginType.Google.rawValue) {
            GIDSignIn.sharedInstance().signOut()
        } else if (loginType == DataManager.LoginType.Facebook.rawValue) {
            let loginManager = LoginManager()
            if let _ = AccessToken.current {
                loginManager.logOut()
            }
        }
        
        UserDefaults.standard.setValue(DataManager.LoginType.None.rawValue, forKey: "login_type")
        DataManager.currentUser = nil
        
        if let parent = self.navigationController {
            if let root = parent.navigationController {
                root.popToRootViewController(animated: true)
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentCharacterCount = textField.text?.count ?? 0
        if range.length + range.location > currentCharacterCount {
            return false
        }
        
        let newLength = currentCharacterCount + string.count - range.length
        return newLength <= 5
    }
    
    // MARK: - UIPickerViewDataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (pickerView.tag == 1) {
            if let licenses = DataManager.licenses {
                return licenses.count
            }
            
            return 0
        } else if (pickerView.tag == 2) {
            return 50
        }
        
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView.tag == 1 {
            if let licenses = DataManager.licenses {
                return licenses[row].name
            }
        } else {
            if row == 0 {
                return "\(row + 1) Year"
            } else {
                return "\(row + 1) Years"
            }
        }
        
        return ""
    }
}
