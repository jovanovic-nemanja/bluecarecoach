//
//  CredentialTableViewCell.swift
//  BluelyHub
//
//  Created by Bozo Krkeljas on 2/2/21.
//

import UIKit

class CredentialTableViewCell: UITableViewCell {

    @IBOutlet weak var checkView: UIView!
    @IBOutlet weak var checkImage: UIImageView!
    //    @IBOutlet weak var statusView: UIView!
    @IBOutlet weak var imageCover: UIImageView!
    @IBOutlet weak var labelTitle: UILabel!

    //    @IBOutlet weak var labelCreator: UILabel!
//    @IBOutlet weak var labelExpireDate: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    public func setCredential(_ credential: Credential) {
        
            
        
        
        if credential.isSelected ??  false {
            checkImage.isHidden = false
        }
        else{
            checkImage.isHidden = true
        }
        
        if let title = credential.title {
            labelTitle.text = title
        }
        
        if let creator = credential.created_by, let userID = Int(creator) {
            if userID == DataManager.currentUser?.id {
//                labelCreator.text = "Created by You"
            } else {
//                labelCreator.text = "Created by Default"
            }
        }

        if ((credential.expire_date) != nil) {
//            labelExpireDate.text = expire

            if let expired = credential.expired, let isExpired = Int(expired) {
                if isExpired < 0 {
                    imageCover.tintColor = #colorLiteral(red: 1, green: 0.5665674806, blue: 0.1932453811, alpha: 1)
                } else {
                    imageCover.tintColor = UIColor.green
                }
            } else {
                imageCover.tintColor = UIColor.red
            }
        } else {
//            labelExpireDate.text = "Not set"
            imageCover.tintColor = UIColor.gray
        }
    }
}
